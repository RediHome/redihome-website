'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Navigation, Footer, colors } from '../components';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    interest: 'general'
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // In production, this would send to your backend
    // For now, we'll show a success message and open email
    const subject = encodeURIComponent(`RediHome Inquiry: ${formData.interest}`);
    const body = encodeURIComponent(`Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\n\nMessage:\n${formData.message}`);
    window.location.href = `mailto:sales@redihome.io?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <div style={{ 
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      background: colors.background,
      color: colors.text,
      minHeight: '100vh'
    }}>
      <Navigation />
      
      {/* Hero Section */}
      <section style={{
        paddingTop: 140,
        paddingBottom: 60,
        background: `linear-gradient(180deg, ${colors.background} 0%, ${colors.backgroundAlt} 100%)`,
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 24px' }}>
          <h1 className="headline-font" style={{
            fontSize: 'clamp(36px, 5vw, 56px)',
            lineHeight: 1.1,
            fontWeight: 600,
            color: colors.text,
            marginBottom: 24
          }}>
            Get in <span style={{ color: colors.primary }}>Touch</span>
          </h1>
          
          <p style={{
            fontSize: 18,
            lineHeight: 1.7,
            color: colors.textLight,
            maxWidth: 500,
            margin: '0 auto'
          }}>
            Have questions? Ready to start your homeownership journey? We'd love to hear from you.
          </p>
        </div>
      </section>
      
      {/* Contact Content */}
      <section style={{ padding: '60px 24px 100px', background: colors.background }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div className="grid-2-col" style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 60 }}>
            {/* Contact Info */}
            <div>
              <h2 className="headline-font" style={{ fontSize: 28, color: colors.text, marginBottom: 32 }}>
                Contact Information
              </h2>
              
              <div style={{ marginBottom: 32 }}>
                <div className="hover-lift" style={{
                  background: 'white',
                  borderRadius: 16,
                  padding: 24,
                  marginBottom: 16,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.06)'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{
                      width: 48,
                      height: 48,
                      borderRadius: 12,
                      background: `${colors.primary}15`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 24
                    }}>
                      📧
                    </div>
                    <div>
                      <div style={{ fontSize: 14, color: colors.textLight, marginBottom: 2 }}>Email Us</div>
                      <a href="mailto:sales@redihome.io" style={{ fontSize: 18, fontWeight: 600, color: colors.primary, textDecoration: 'none' }}>
                        sales@redihome.io
                      </a>
                    </div>
                  </div>
                </div>
                
                <div className="hover-lift" style={{
                  background: 'white',
                  borderRadius: 16,
                  padding: 24,
                  marginBottom: 16,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.06)'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{
                      width: 48,
                      height: 48,
                      borderRadius: 12,
                      background: `${colors.accent}15`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 24
                    }}>
                      📞
                    </div>
                    <div>
                      <div style={{ fontSize: 14, color: colors.textLight, marginBottom: 2 }}>Call Us</div>
                      <a href="tel:205-612-5445" style={{ fontSize: 18, fontWeight: 600, color: colors.primary, textDecoration: 'none' }}>
                        (205) 612-5445
                      </a>
                    </div>
                  </div>
                </div>
                
                <div className="hover-lift" style={{
                  background: 'white',
                  borderRadius: 16,
                  padding: 24,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.06)'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{
                      width: 48,
                      height: 48,
                      borderRadius: 12,
                      background: `${colors.primary}15`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 24
                    }}>
                      📍
                    </div>
                    <div>
                      <div style={{ fontSize: 14, color: colors.textLight, marginBottom: 2 }}>Location</div>
                      <div style={{ fontSize: 18, fontWeight: 600, color: colors.text }}>
                        Birmingham, Alabama
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Quick Links */}
              <div style={{
                background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryLight} 100%)`,
                borderRadius: 20,
                padding: 28,
                color: 'white'
              }}>
                <h3 style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Ready to Get Started?</h3>
                <p style={{ fontSize: 14, opacity: 0.9, lineHeight: 1.6, marginBottom: 20 }}>
                  The fastest way to begin is to find a lot and start designing your home.
                </p>
                <a 
                  href="https://homepoint.co/redihome"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    background: colors.accent,
                    color: 'white',
                    padding: '12px 24px',
                    borderRadius: 8,
                    fontWeight: 600,
                    fontSize: 14,
                    textDecoration: 'none'
                  }}
                >
                  Find a Lot →
                </a>
              </div>
            </div>
            
            {/* Contact Form */}
            <div>
              <div style={{
                background: 'white',
                borderRadius: 24,
                padding: 40,
                boxShadow: '0 4px 40px rgba(0,0,0,0.08)'
              }}>
                {submitted ? (
                  <div style={{ textAlign: 'center', padding: '40px 0' }}>
                    <div style={{ fontSize: 64, marginBottom: 20 }}>✉️</div>
                    <h3 className="headline-font" style={{ fontSize: 28, color: colors.primary, marginBottom: 12 }}>
                      Thanks for reaching out!
                    </h3>
                    <p style={{ fontSize: 16, color: colors.textLight, lineHeight: 1.6 }}>
                      Your email app should have opened with your message. If not, feel free to email us directly at{' '}
                      <a href="mailto:sales@redihome.io" style={{ color: colors.primary }}>sales@redihome.io</a>
                    </p>
                  </div>
                ) : (
                  <>
                    <h2 className="headline-font" style={{ fontSize: 28, color: colors.text, marginBottom: 8 }}>
                      Send Us a Message
                    </h2>
                    <p style={{ fontSize: 15, color: colors.textLight, marginBottom: 32 }}>
                      Fill out the form below and we'll get back to you within 24 hours.
                    </p>
                    
                    <form onSubmit={handleSubmit}>
                      <div style={{ marginBottom: 20 }}>
                        <label style={{ display: 'block', fontSize: 14, fontWeight: 500, color: colors.text, marginBottom: 8 }}>
                          Your Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          style={{
                            width: '100%',
                            padding: '14px 16px',
                            borderRadius: 10,
                            border: '2px solid #eee',
                            fontSize: 16,
                            transition: 'border-color 0.2s'
                          }}
                          placeholder="John Smith"
                        />
                      </div>
                      
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
                        <div>
                          <label style={{ display: 'block', fontSize: 14, fontWeight: 500, color: colors.text, marginBottom: 8 }}>
                            Email *
                          </label>
                          <input
                            type="email"
                            required
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            style={{
                              width: '100%',
                              padding: '14px 16px',
                              borderRadius: 10,
                              border: '2px solid #eee',
                              fontSize: 16
                            }}
                            placeholder="john@example.com"
                          />
                        </div>
                        
                        <div>
                          <label style={{ display: 'block', fontSize: 14, fontWeight: 500, color: colors.text, marginBottom: 8 }}>
                            Phone
                          </label>
                          <input
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            style={{
                              width: '100%',
                              padding: '14px 16px',
                              borderRadius: 10,
                              border: '2px solid #eee',
                              fontSize: 16
                            }}
                            placeholder="(205) 555-1234"
                          />
                        </div>
                      </div>
                      
                      <div style={{ marginBottom: 20 }}>
                        <label style={{ display: 'block', fontSize: 14, fontWeight: 500, color: colors.text, marginBottom: 8 }}>
                          I'm interested in...
                        </label>
                        <select
                          value={formData.interest}
                          onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                          style={{
                            width: '100%',
                            padding: '14px 16px',
                            borderRadius: 10,
                            border: '2px solid #eee',
                            fontSize: 16,
                            background: 'white'
                          }}
                        >
                          <option value="general">General Information</option>
                          <option value="buying">Buying a Home</option>
                          <option value="financing">Financing Questions</option>
                          <option value="lots">Available Lots</option>
                          <option value="other">Something Else</option>
                        </select>
                      </div>
                      
                      <div style={{ marginBottom: 24 }}>
                        <label style={{ display: 'block', fontSize: 14, fontWeight: 500, color: colors.text, marginBottom: 8 }}>
                          Your Message *
                        </label>
                        <textarea
                          required
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          rows={5}
                          style={{
                            width: '100%',
                            padding: '14px 16px',
                            borderRadius: 10,
                            border: '2px solid #eee',
                            fontSize: 16,
                            resize: 'vertical'
                          }}
                          placeholder="Tell us how we can help..."
                        />
                      </div>
                      
                      <button
                        type="submit"
                        className="btn-accent"
                        style={{ width: '100%', justifyContent: 'center' }}
                      >
                        Send Message →
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Quick Section */}
      <section style={{ padding: '80px 24px', background: colors.backgroundAlt }}>
        <div style={{ maxWidth: 800, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="headline-font" style={{ fontSize: 28, color: colors.text, marginBottom: 16 }}>
            Common Questions
          </h2>
          <p style={{ fontSize: 16, color: colors.textLight, marginBottom: 32 }}>
            Before you reach out, here are some quick answers
          </p>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, textAlign: 'left' }}>
            {[
              { q: 'Where are you currently building?', a: 'We\'re currently focused on infill lots throughout Birmingham, Alabama.' },
              { q: 'What\'s the minimum credit score?', a: 'Our financing partner works with credit scores of 620 and above.' },
              { q: 'How long does the process take?', a: 'From deposit to keys is approximately 10 weeks—about 2 weeks for approval and 8 weeks for construction.' },
              { q: 'Is the deposit refundable?', a: 'Yes, your $500 deposit is fully refundable if you don\'t qualify for financing.' }
            ].map(item => (
              <div key={item.q} style={{
                background: 'white',
                borderRadius: 12,
                padding: 20,
                boxShadow: '0 2px 10px rgba(0,0,0,0.04)'
              }}>
                <div style={{ fontWeight: 600, color: colors.primary, marginBottom: 6 }}>{item.q}</div>
                <div style={{ fontSize: 14, color: colors.textLight }}>{item.a}</div>
              </div>
            ))}
          </div>
          
          <div style={{ marginTop: 32 }}>
            <Link href="/how-it-works" className="btn-secondary">
              View All FAQs →
            </Link>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
