'use client';

import Link from 'next/link';
import { Navigation, Footer, CTASection, colors } from '../components';

export default function HomesPage() {
  const availablePlans = [
    {
      name: 'The Magnolia',
      sqft: '1,472',
      beds: 3,
      baths: 2,
      features: ['Home Office', 'Open Floor Plan', 'Covered Patio'],
      status: 'available',
      price: '$240,000'
    },
    {
      name: 'The Dogwood',
      sqft: '1,425',
      beds: 3,
      baths: 2,
      features: ['Efficient Layout', 'Large Kitchen', 'Master Suite'],
      status: 'available',
      price: '$235,000'
    }
  ];

  const comingSoonPlans = [
    { name: 'The Redbud', desc: 'Compact & efficient design for first-time buyers' },
    { name: 'The Live Oak', desc: 'Spacious layout with 4 bedroom option' },
    { name: 'The Longleaf', desc: 'Our largest plan with bonus room' }
  ];

  return (
    <div style={{ 
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      background: colors.background,
      color: colors.text,
      minHeight: '100vh'
    }}>
      <Navigation />
      
      {/* Hero Section */}
      <section style={{
        paddingTop: 140,
        paddingBottom: 80,
        background: `linear-gradient(180deg, ${colors.background} 0%, ${colors.backgroundAlt} 100%)`,
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 24px' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            background: `${colors.accent}18`,
            padding: '8px 16px',
            borderRadius: 100,
            marginBottom: 24
          }}>
            <span style={{ fontSize: 14, fontWeight: 500, color: colors.accentDark }}>Named for Alabama's Beautiful Trees</span>
          </div>
          
          <h1 className="headline-font" style={{
            fontSize: 'clamp(36px, 5vw, 56px)',
            lineHeight: 1.1,
            fontWeight: 600,
            color: colors.text,
            marginBottom: 24
          }}>
            Our <span style={{ color: colors.primary }}>Home Plans</span>
          </h1>
          
          <p style={{
            fontSize: 18,
            lineHeight: 1.7,
            color: colors.textLight,
            maxWidth: 600,
            margin: '0 auto'
          }}>
            Quality homes designed for real life. Each plan features 20+ customizations so you can make it your own.
          </p>
        </div>
      </section>
      
      {/* Available Plans */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 32, color: colors.text, marginBottom: 8 }}>
              Available Now
            </h2>
            <p style={{ fontSize: 16, color: colors.textLight }}>
              Ready to customize and build on your lot
            </p>
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 32 }}>
            {availablePlans.map(plan => (
              <div key={plan.name} className="hover-lift" style={{
                background: 'white',
                borderRadius: 24,
                overflow: 'hidden',
                boxShadow: '0 4px 30px rgba(0,0,0,0.08)'
              }}>
                {/* Plan Image Placeholder */}
                <div style={{
                  height: 280,
                  background: `linear-gradient(135deg, ${colors.primary}15 0%, ${colors.accent}15 100%)`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative'
                }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 80, marginBottom: 8 }}>🏡</div>
                    <div style={{ fontSize: 14, color: colors.textLight }}>Floor Plan Preview</div>
                  </div>
                  <div style={{
                    position: 'absolute',
                    top: 16,
                    right: 16,
                    background: colors.accent,
                    color: 'white',
                    padding: '6px 12px',
                    borderRadius: 20,
                    fontSize: 12,
                    fontWeight: 600
                  }}>
                    AVAILABLE
                  </div>
                </div>
                
                <div style={{ padding: 32 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                    <div>
                      <h3 className="headline-font" style={{ fontSize: 28, color: colors.primary, marginBottom: 4 }}>
                        {plan.name}
                      </h3>
                      <div style={{ fontSize: 14, color: colors.textLight }}>
                        {plan.sqft} sq ft • {plan.beds} BD / {plan.baths} BA
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 12, color: colors.textLight }}>Starting at</div>
                      <div className="headline-font" style={{ fontSize: 24, color: colors.accent, fontWeight: 700 }}>
                        {plan.price}
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ marginBottom: 24 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: colors.textLight, marginBottom: 8 }}>FEATURES</div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {plan.features.map(feature => (
                        <span key={feature} style={{
                          background: `${colors.primary}10`,
                          color: colors.primary,
                          padding: '6px 12px',
                          borderRadius: 20,
                          fontSize: 13,
                          fontWeight: 500
                        }}>
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div style={{ display: 'flex', gap: 12 }}>
                    <a 
                      href="https://homepoint.co/redihome"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-accent"
                      style={{ flex: 1, justifyContent: 'center', padding: '14px 24px' }}
                    >
                      Find a Lot for This Home
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Coming Soon Plans */}
      <section style={{ padding: '80px 24px', background: colors.backgroundAlt }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 32, color: colors.text, marginBottom: 8 }}>
              Coming Soon
            </h2>
            <p style={{ fontSize: 16, color: colors.textLight }}>
              We're working on these plans now—more options on the way
            </p>
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24 }}>
            {comingSoonPlans.map(plan => (
              <div key={plan.name} className="hover-lift" style={{
                background: 'white',
                borderRadius: 20,
                padding: 32,
                boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
                border: '2px dashed rgba(74, 95, 168, 0.2)',
                textAlign: 'center'
              }}>
                <div style={{
                  width: 60,
                  height: 60,
                  borderRadius: '50%',
                  background: `${colors.primary}10`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 16px',
                  fontSize: 28
                }}>
                  🌳
                </div>
                <h3 className="headline-font" style={{ fontSize: 24, color: colors.primary, marginBottom: 8 }}>
                  {plan.name}
                </h3>
                <p style={{ fontSize: 14, color: colors.textLight, lineHeight: 1.5 }}>
                  {plan.desc}
                </p>
                <div style={{
                  marginTop: 16,
                  padding: '8px 16px',
                  background: `${colors.accent}15`,
                  borderRadius: 20,
                  display: 'inline-block',
                  fontSize: 12,
                  fontWeight: 600,
                  color: colors.accentDark
                }}>
                  IN DEVELOPMENT
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Customization Section */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
            Make It Yours with 20+ Customizations
          </h2>
          <p style={{ fontSize: 18, color: colors.textLight, lineHeight: 1.7, marginBottom: 48 }}>
            Every RediHome can be personalized to fit your style. Choose from curated options for both exterior and interior finishes.
          </p>
          
          <div className="grid-2-col" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, textAlign: 'left' }}>
            <div className="hover-lift" style={{
              background: 'white',
              borderRadius: 20,
              padding: 32,
              boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
            }}>
              <h3 style={{ fontSize: 20, fontWeight: 600, color: colors.primary, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 28 }}>🏠</span> Exterior Options
              </h3>
              <ul style={{ listStyle: 'none', padding: 0 }}>
                {['Siding colors & materials', 'Roof style & color', 'Front door design', 'Porch & patio options', 'Landscaping packages'].map(item => (
                  <li key={item} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, color: colors.textLight, fontSize: 15 }}>
                    <span style={{ color: colors.accent, fontWeight: 700 }}>✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="hover-lift" style={{
              background: 'white',
              borderRadius: 20,
              padding: 32,
              boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
            }}>
              <h3 style={{ fontSize: 20, fontWeight: 600, color: colors.primary, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 28 }}>🛋️</span> Interior Options
              </h3>
              <ul style={{ listStyle: 'none', padding: 0 }}>
                {['Flooring materials & colors', 'Cabinet styles & finishes', 'Countertop selections', 'Fixture & hardware choices', 'Paint color schemes'].map(item => (
                  <li key={item} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, color: colors.textLight, fontSize: 15 }}>
                    <span style={{ color: colors.accent, fontWeight: 700 }}>✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Quality Section */}
      <section style={{
        padding: '80px 24px',
        background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryLight} 100%)`,
        color: 'white'
      }}>
        <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', marginBottom: 16 }}>
            Built Better Means Built to Last
          </h2>
          <p style={{ fontSize: 18, opacity: 0.9, lineHeight: 1.7, marginBottom: 48 }}>
            Every RediHome is constructed with quality materials and methods that exceed builder-grade standards.
          </p>
          
          <div className="grid-4-col" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
            {[
              { icon: '🏗️', title: '2x6 Framing', desc: 'Stronger, better insulated walls' },
              { icon: '🌡️', title: 'Spray Foam', desc: 'Closed-cell insulation throughout' },
              { icon: '💨', title: 'Air-Tight', desc: 'Verified construction quality' },
              { icon: '⚡', title: 'Low Energy', desc: 'Efficient design saves money' }
            ].map(item => (
              <div key={item.title} style={{
                background: 'rgba(255,255,255,0.1)',
                borderRadius: 16,
                padding: 24,
                border: '1px solid rgba(255,255,255,0.15)'
              }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>{item.icon}</div>
                <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>{item.title}</div>
                <div style={{ fontSize: 13, opacity: 0.8 }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <CTASection />
      <Footer />
    </div>
  );
}
