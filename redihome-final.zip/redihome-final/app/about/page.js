'use client';

import Link from 'next/link';
import { Navigation, Footer, CTASection, colors } from '../components';

export default function AboutPage() {
  return (
    <div style={{ 
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      background: colors.background,
      color: colors.text,
      minHeight: '100vh'
    }}>
      <Navigation />
      
      {/* Hero Section */}
      <section style={{
        paddingTop: 140,
        paddingBottom: 80,
        background: `linear-gradient(180deg, ${colors.background} 0%, ${colors.backgroundAlt} 100%)`,
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 24px' }}>
          <h1 className="headline-font" style={{
            fontSize: 'clamp(36px, 5vw, 56px)',
            lineHeight: 1.1,
            fontWeight: 600,
            color: colors.text,
            marginBottom: 24
          }}>
            About <span style={{ color: colors.primary }}>RediHome</span>
          </h1>
          
          <p style={{
            fontSize: 18,
            lineHeight: 1.7,
            color: colors.textLight,
            maxWidth: 600,
            margin: '0 auto'
          }}>
            We're on a mission to make homeownership accessible for Birmingham's working families—not through subsidies, but through smarter building.
          </p>
        </div>
      </section>
      
      {/* Founder Story */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div className="grid-2-col" style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: 48, alignItems: 'center' }}>
            <div>
              <div style={{
                width: '100%',
                aspectRatio: '1',
                borderRadius: 24,
                background: `linear-gradient(135deg, ${colors.primary}20 0%, ${colors.accent}20 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 80, marginBottom: 8 }}>👤</div>
                  <div style={{ fontSize: 14, color: colors.textLight }}>Founder Photo</div>
                </div>
              </div>
            </div>
            
            <div>
              <div style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 8,
                background: `${colors.accent}18`,
                padding: '8px 16px',
                borderRadius: 100,
                marginBottom: 20
              }}>
                <span style={{ fontSize: 14, fontWeight: 500, color: colors.accentDark }}>Founder's Story</span>
              </div>
              
              <h2 className="headline-font" style={{ fontSize: 32, color: colors.text, marginBottom: 20 }}>
                Why I Started RediHome
              </h2>
              
              <div style={{ fontSize: 16, color: colors.textLight, lineHeight: 1.8 }}>
                <p style={{ marginBottom: 16 }}>
                  I spent five years researching every method of building affordable housing—modular systems, international suppliers, traditional stick-built, panelized construction. I traveled, studied, experimented, and learned what works and what doesn't.
                </p>
                <p style={{ marginBottom: 16 }}>
                  What I found was this: affordable housing shouldn't mean subsidies, waiting lists, or compromise on quality. It should mean building smarter—eliminating waste, streamlining processes, and passing those savings to families who deserve to own their homes.
                </p>
                <p style={{ marginBottom: 16 }}>
                  I saw neighborhoods in Birmingham where 80% of residents were renters. Working families—teachers, nurses, tradespeople—paying rent to build someone else's wealth. That's not how it should be.
                </p>
                <p>
                  RediHome exists to flip that equation. We build quality homes that working families can actually afford, with financing that doesn't require years of saving. Our goal is to transform rental neighborhoods into homeownership communities—one family at a time.
                </p>
              </div>
              
              <div style={{ marginTop: 24 }}>
                <div style={{ fontWeight: 600, color: colors.primary, fontSize: 18 }}>Jacob</div>
                <div style={{ color: colors.textLight, fontSize: 14 }}>Founder & CEO, RediHome</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Mission & Vision */}
      <section style={{
        padding: '80px 24px',
        background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryLight} 100%)`,
        color: 'white'
      }}>
        <div style={{ maxWidth: 1000, margin: '0 auto' }}>
          <div className="grid-2-col" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
            <div>
              <div style={{ fontSize: 48, marginBottom: 20 }}>🎯</div>
              <h3 className="headline-font" style={{ fontSize: 28, marginBottom: 16 }}>Our Mission</h3>
              <p style={{ fontSize: 17, lineHeight: 1.8, opacity: 0.9 }}>
                To make quality homeownership accessible and affordable for Birmingham's working families through innovative building practices, strategic partnerships, and a commitment to community wealth-building.
              </p>
            </div>
            
            <div>
              <div style={{ fontSize: 48, marginBottom: 20 }}>🌟</div>
              <h3 className="headline-font" style={{ fontSize: 28, marginBottom: 16 }}>Our Vision</h3>
              <p style={{ fontSize: 17, lineHeight: 1.8, opacity: 0.9 }}>
                To transform Birmingham's neighborhoods from 80% renters to 80% homeowners—creating stable, thriving communities where families can build generational wealth and put down roots.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Our Values */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 1000, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              What We Stand For
            </h2>
          </div>
          
          <div className="grid-3-col" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {[
              {
                icon: '🏠',
                title: 'Owner-Occupants Only',
                desc: 'We sell exclusively to people who will live in their homes. No investors, no flippers, no speculation. Every home we build is for a family, not a portfolio.'
              },
              {
                icon: '⭐',
                title: 'Quality Over Shortcuts',
                desc: 'We don\'t cut corners to hit price points. Our homes feature 2x6 framing, spray foam insulation, and air-tight construction. Built better means built to last.'
              },
              {
                icon: '🤝',
                title: 'Dignity, Not Charity',
                desc: 'We\'re not a nonprofit and we\'re not subsidized. We\'ve built a profitable model that makes homeownership accessible—treating working families as customers, not cases.'
              },
              {
                icon: '📍',
                title: 'Infill, Not Sprawl',
                desc: 'We build in established neighborhoods, not at the edge of town. Strengthening existing communities, shortening commutes, and revitalizing blocks that need investment.'
              },
              {
                icon: '💰',
                title: 'Transparent Pricing',
                desc: 'No hidden fees, no surprises. What we quote is what you pay. We believe in honest business and long-term relationships.'
              },
              {
                icon: '🌱',
                title: 'Community Wealth',
                desc: 'Homeownership is the #1 way working families build wealth. Every home we sell is an investment in a family\'s future and their community\'s stability.'
              }
            ].map(value => (
              <div key={value.title} className="hover-lift" style={{
                background: 'white',
                borderRadius: 20,
                padding: 28,
                boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
              }}>
                <div style={{ fontSize: 36, marginBottom: 16 }}>{value.icon}</div>
                <h3 style={{ fontSize: 18, fontWeight: 600, color: colors.primary, marginBottom: 12 }}>{value.title}</h3>
                <p style={{ fontSize: 14, color: colors.textLight, lineHeight: 1.6 }}>{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* The RediHome Approach */}
      <section style={{ padding: '80px 24px', background: colors.backgroundAlt }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              How We Make It Work
            </h2>
            <p style={{ fontSize: 18, color: colors.textLight, maxWidth: 600, margin: '0 auto' }}>
              Our approach is different from traditional builders—and that's by design.
            </p>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              {
                title: 'Presale Model',
                desc: 'We don\'t build spec homes sitting empty. Your home is sold before we build it, which eliminates waste and lets us pass savings to you.'
              },
              {
                title: 'Strategic Partnerships',
                desc: 'From our 0% down, no PMI financing through Cadence Bank to flat-fee real estate services, our partnerships create real value for buyers.'
              },
              {
                title: 'Standardized Design, Personalized Choice',
                desc: 'We offer a curated set of floor plans with 20+ customizations. This lets us build efficiently while still giving you a home that feels like yours.'
              },
              {
                title: 'Infill Development',
                desc: 'We purchase and prepare lots in established neighborhoods, handling permits and foundations before you even find us. When you\'re ready, we\'re ready.'
              },
              {
                title: 'Vertical Integration',
                desc: 'We control the process from lot acquisition to key handoff. No middlemen adding cost without adding value.'
              }
            ].map(item => (
              <div key={item.title} className="hover-lift" style={{
                background: 'white',
                borderRadius: 16,
                padding: 24,
                boxShadow: '0 4px 20px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontSize: 18, fontWeight: 600, color: colors.primary, marginBottom: 8 }}>{item.title}</h3>
                <p style={{ fontSize: 15, color: colors.textLight, lineHeight: 1.7 }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Birmingham Focus */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 800, margin: '0 auto', textAlign: 'center' }}>
          <div style={{ fontSize: 64, marginBottom: 24 }}>📍</div>
          <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
            Built in Birmingham
          </h2>
          <p style={{ fontSize: 18, color: colors.textLight, lineHeight: 1.8, marginBottom: 32 }}>
            We're starting right here in Birmingham, Alabama—our home. We know these neighborhoods, we understand these families, and we're committed to making a real difference in this community before we expand anywhere else.
          </p>
          <p style={{ fontSize: 16, color: colors.textLight, lineHeight: 1.8 }}>
            Birmingham has incredible potential. Working families power this city every day—teaching our kids, caring for our sick, building our buildings, keeping our systems running. They deserve to own a piece of the community they serve.
          </p>
        </div>
      </section>
      
      <CTASection />
      <Footer />
    </div>
  );
}
