'use client';

import Link from 'next/link';
import { Navigation, Footer, CTASection, colors } from '../components';

export default function HowItWorksPage() {
  const steps = [
    {
      num: '01',
      title: 'Find Your Lot',
      icon: '📍',
      description: 'We prepare infill lots throughout Birmingham\'s established neighborhoods. Each lot has a QR code you can scan to start designing your home right from the property.',
      details: [
        'Lots are already permitted and ready',
        'Foundation is poured and waiting',
        'Utilities are connected',
        'QR code links directly to the design platform'
      ]
    },
    {
      num: '02',
      title: 'Design Your Home',
      icon: '🏠',
      description: 'Use our easy design platform to customize your home. Choose your floor plan, exterior style, and interior finishes from our curated selection of 20+ options.',
      details: [
        'Multiple floor plans to choose from',
        'Exterior colors and materials',
        'Interior finishes and fixtures',
        'See your home come together in real-time'
      ]
    },
    {
      num: '03',
      title: 'Get Qualified',
      icon: '✅',
      description: 'Answer a few quick questions about your credit, income, and intentions. We\'ll connect you with our lending partner who specializes in making homeownership accessible.',
      details: [
        'Credit scores starting at 620',
        '0% down payment programs available',
        'No PMI required',
        'Pre-qualification in minutes'
      ]
    },
    {
      num: '04',
      title: 'Secure Your Spot',
      icon: '🔒',
      description: 'A $500 refundable deposit holds your lot and locks in your home design. First deposit wins, so don\'t wait if you find the perfect spot.',
      details: [
        'Fully refundable if you don\'t qualify',
        'Holds your specific lot',
        'Locks in your customizations',
        '3-day window to complete bank application'
      ]
    },
    {
      num: '05',
      title: 'Get Approved',
      icon: '🏦',
      description: 'Our lending partner handles verification and underwriting. You\'ll know if you\'re approved within about a week. If approved, we set your closing date.',
      details: [
        'Bank calls to verify your information',
        'Document verification process',
        'Approval typically within 1 week',
        'Closing date set 2 months out'
      ]
    },
    {
      num: '06',
      title: 'We Build, You Move In',
      icon: '🔑',
      description: '8 weeks later, your home is complete. We hand you the keys and you\'re officially a homeowner. Welcome home.',
      details: [
        'Construction takes approximately 8 weeks',
        'Track progress throughout the build',
        'Final walkthrough before closing',
        'Keys in hand on closing day'
      ]
    }
  ];

  const faqs = [
    {
      q: 'What if my credit score is below 620?',
      a: 'We\'ll connect you with credit counseling resources to help you improve your score. Many people can raise their score significantly within 6-12 months. We\'ll check in with you monthly and help you get qualified when you\'re ready.'
    },
    {
      q: 'What if I can\'t afford the monthly payment?',
      a: 'If your income doesn\'t currently qualify you, we can connect you with career development resources. We\'ll stay in touch and help you get into a home when your income increases.'
    },
    {
      q: 'Is the $500 deposit really refundable?',
      a: 'Yes. If you don\'t qualify for financing, your deposit is fully refunded. The deposit only becomes non-refundable once you\'re approved and we begin construction.'
    },
    {
      q: 'Can I sell my home to investors?',
      a: 'We sell exclusively to owner-occupants. Our homes come with a right of first refusal clause, meaning if you decide to sell, we have the first opportunity to purchase it back. This helps keep our homes in the hands of families, not investors.'
    },
    {
      q: 'What\'s included in the home price?',
      a: 'The price includes the lot, the completed home with all your customizations, and standard landscaping. You\'ll also get a home warranty for added peace of mind.'
    }
  ];

  return (
    <div style={{ 
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      background: colors.background,
      color: colors.text,
      minHeight: '100vh'
    }}>
      <Navigation />
      
      {/* Hero Section */}
      <section style={{
        paddingTop: 140,
        paddingBottom: 80,
        background: `linear-gradient(180deg, ${colors.background} 0%, ${colors.backgroundAlt} 100%)`,
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 24px' }}>
          <h1 className="headline-font" style={{
            fontSize: 'clamp(36px, 5vw, 56px)',
            lineHeight: 1.1,
            fontWeight: 600,
            color: colors.text,
            marginBottom: 24
          }}>
            How <span style={{ color: colors.primary }}>RediHome</span> Works
          </h1>
          
          <p style={{
            fontSize: 18,
            lineHeight: 1.7,
            color: colors.textLight,
            maxWidth: 600,
            margin: '0 auto 32px'
          }}>
            We've simplified the path to homeownership. From finding your lot to getting your keys, here's exactly what to expect.
          </p>
          
          <div className="stats-row" style={{ display: 'flex', gap: 40, justifyContent: 'center' }}>
            {[
              { value: '6 Steps', label: 'Simple Process' },
              { value: '8 Weeks', label: 'Build Time' },
              { value: '0%', label: 'Down Payment' }
            ].map(stat => (
              <div key={stat.label}>
                <div className="headline-font" style={{ fontSize: 28, fontWeight: 700, color: colors.primary }}>{stat.value}</div>
                <div style={{ fontSize: 14, color: '#888', marginTop: 4 }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Steps Section */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          {steps.map((step, idx) => (
            <div key={step.num} style={{
              display: 'grid',
              gridTemplateColumns: '80px 1fr',
              gap: 32,
              marginBottom: idx < steps.length - 1 ? 48 : 0,
              position: 'relative'
            }}>
              {/* Step Number */}
              <div style={{ position: 'relative' }}>
                <div style={{
                  width: 64,
                  height: 64,
                  borderRadius: 16,
                  background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryLight} 100%)`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 28,
                  boxShadow: `0 10px 30px ${colors.primary}30`
                }}>
                  {step.icon}
                </div>
                {idx < steps.length - 1 && (
                  <div style={{
                    position: 'absolute',
                    top: 80,
                    left: 31,
                    width: 2,
                    height: 'calc(100% + 32px)',
                    background: `linear-gradient(180deg, ${colors.primary}30 0%, transparent 100%)`
                  }} />
                )}
              </div>
              
              {/* Step Content */}
              <div className="hover-lift" style={{
                background: 'white',
                borderRadius: 20,
                padding: 32,
                boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
              }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: colors.accent, marginBottom: 8 }}>
                  STEP {step.num}
                </div>
                <h3 className="headline-font" style={{ fontSize: 28, color: colors.primary, marginBottom: 12 }}>
                  {step.title}
                </h3>
                <p style={{ fontSize: 16, color: colors.textLight, lineHeight: 1.7, marginBottom: 20 }}>
                  {step.description}
                </p>
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {step.details.map(detail => (
                    <li key={detail} style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 10,
                      marginBottom: 8,
                      fontSize: 14,
                      color: colors.textLight
                    }}>
                      <span style={{ color: colors.accent, fontWeight: 700 }}>✓</span>
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </section>
      
      {/* Timeline Visual */}
      <section style={{
        padding: '80px 24px',
        background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryLight} 100%)`,
        color: 'white'
      }}>
        <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', marginBottom: 16 }}>
            Your Timeline to Homeownership
          </h2>
          <p style={{ fontSize: 18, opacity: 0.9, marginBottom: 48 }}>
            From first scan to keys in hand
          </p>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
            {[
              { time: 'Day 1', event: 'Find & Design' },
              { time: 'Day 1-3', event: 'Deposit & Apply' },
              { time: 'Week 1-2', event: 'Get Approved' },
              { time: 'Week 2-10', event: 'We Build' },
              { time: 'Week 10', event: 'Move In! 🔑' }
            ].map((item, idx) => (
              <div key={item.time} style={{ flex: '1 1 150px', textAlign: 'center' }}>
                <div style={{
                  width: 60,
                  height: 60,
                  borderRadius: '50%',
                  background: 'rgba(255,255,255,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 12px',
                  fontSize: 20,
                  fontWeight: 700
                }}>
                  {idx + 1}
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{item.time}</div>
                <div style={{ fontSize: 16, opacity: 0.9 }}>{item.event}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 800, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              Common Questions
            </h2>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {faqs.map(faq => (
              <div key={faq.q} className="hover-lift" style={{
                background: 'white',
                borderRadius: 16,
                padding: 24,
                boxShadow: '0 4px 20px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontSize: 18, fontWeight: 600, color: colors.primary, marginBottom: 12 }}>
                  {faq.q}
                </h3>
                <p style={{ fontSize: 15, color: colors.textLight, lineHeight: 1.7 }}>
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <CTASection />
      <Footer />
    </div>
  );
}
