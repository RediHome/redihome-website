'use client';

import Link from 'next/link';
import { Navigation, Footer, CTASection, colors } from '../components';

export default function FinancingPage() {
  return (
    <div style={{ 
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      background: colors.background,
      color: colors.text,
      minHeight: '100vh'
    }}>
      <Navigation />
      
      {/* Hero Section */}
      <section style={{
        paddingTop: 140,
        paddingBottom: 80,
        background: `linear-gradient(180deg, ${colors.background} 0%, ${colors.backgroundAlt} 100%)`,
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 24px' }}>
          <h1 className="headline-font" style={{
            fontSize: 'clamp(36px, 5vw, 56px)',
            lineHeight: 1.1,
            fontWeight: 600,
            color: colors.text,
            marginBottom: 24
          }}>
            Financing That <span style={{ color: colors.primary }}>Makes Sense</span>
          </h1>
          
          <p style={{
            fontSize: 18,
            lineHeight: 1.7,
            color: colors.textLight,
            maxWidth: 600,
            margin: '0 auto'
          }}>
            Through our partnership with Cadence Bank's Right@Home program, we've created real pathways to homeownership for working families.
          </p>
        </div>
      </section>
      
      {/* Key Benefits */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div className="grid-4-col" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
            {[
              { value: '0%', label: 'Down Payment', desc: 'Keep your savings for moving day and furnishing your new home.', icon: '💰' },
              { value: 'No', label: 'PMI Required', desc: 'More money stays in your pocket every single month.', icon: '🛡️' },
              { value: '620+', label: 'Credit Score', desc: 'Real pathways for real people. Not just the perfect applicants.', icon: '📊' },
              { value: '~1 Week', label: 'Approval Time', desc: 'Know where you stand quickly so you can plan your future.', icon: '⏱️' }
            ].map(item => (
              <div key={item.label} className="hover-lift" style={{
                background: 'white',
                borderRadius: 20,
                padding: 32,
                textAlign: 'center',
                boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
              }}>
                <div style={{ fontSize: 40, marginBottom: 16 }}>{item.icon}</div>
                <div className="headline-font" style={{ fontSize: 36, fontWeight: 700, color: colors.primary }}>{item.value}</div>
                <div style={{ fontSize: 16, fontWeight: 600, color: colors.text, marginBottom: 8 }}>{item.label}</div>
                <div style={{ fontSize: 14, color: colors.textLight, lineHeight: 1.5 }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Payment Calculator Section */}
      <section style={{
        padding: '80px 24px',
        background: `linear-gradient(135deg, ${colors.primaryDark} 0%, ${colors.primary} 50%, ${colors.primaryLight} 100%)`,
        color: 'white'
      }}>
        <div className="grid-2-col" style={{ maxWidth: 1100, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, alignItems: 'center' }}>
          <div>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', marginBottom: 20 }}>
              What Does It Actually Cost?
            </h2>
            <p style={{ fontSize: 17, opacity: 0.9, lineHeight: 1.7, marginBottom: 24 }}>
              Let's be real about the numbers. Here's what a typical RediHome mortgage looks like for a family earning around $65,000 per year.
            </p>
            
            <div style={{
              background: 'rgba(255,255,255,0.1)',
              borderRadius: 16,
              padding: 24,
              border: '1px solid rgba(255,255,255,0.15)'
            }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16, opacity: 0.8 }}>THE 30% RULE</div>
              <p style={{ fontSize: 15, lineHeight: 1.7, opacity: 0.9 }}>
                Financial experts recommend spending no more than 30% of your take-home pay on housing. At $65,000/year, that's about $1,625/month. Our homes are designed to fit within this budget.
              </p>
            </div>
          </div>
          
          <div style={{
            background: 'white',
            borderRadius: 20,
            padding: 32,
            color: colors.text,
            boxShadow: '0 40px 80px rgba(0,0,0,0.25)'
          }}>
            <div style={{ fontSize: 13, color: colors.accent, fontWeight: 600, marginBottom: 6 }}>EXAMPLE: THE MAGNOLIA (1,472 SQ FT)</div>
            <div className="headline-font" style={{ fontSize: 42, fontWeight: 700, color: colors.primary, marginBottom: 24 }}>
              ~$1,650<span style={{ fontSize: 18, fontWeight: 400, color: '#888' }}>/month</span>
            </div>
            
            <div style={{ borderTop: '1px solid #eee', paddingTop: 20 }}>
              {[
                { label: 'Home Price', value: '$240,000' },
                { label: 'Down Payment', value: '$0', highlight: true },
                { label: 'Loan Amount', value: '$240,000' },
                { label: 'Interest Rate', value: '~7% (varies)' },
                { label: 'PMI', value: '$0', highlight: true },
                { label: 'Property Taxes', value: 'Included in payment' },
                { label: 'Home Insurance', value: 'Included in payment' }
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, paddingBottom: row.label === 'Loan Amount' ? 10 : 0, borderBottom: row.label === 'Loan Amount' ? '1px solid #eee' : 'none' }}>
                  <span style={{ color: '#666' }}>{row.label}</span>
                  <span style={{ fontWeight: 600, color: row.highlight ? colors.accent : colors.text }}>{row.value}</span>
                </div>
              ))}
            </div>
            
            <div style={{
              marginTop: 20,
              padding: 14,
              background: `${colors.primary}08`,
              borderRadius: 10,
              fontSize: 13,
              color: colors.textLight,
              lineHeight: 1.5,
              border: `1px solid ${colors.primary}15`
            }}>
              💡 This example is for illustration. Your actual rate and payment will depend on your specific situation.
            </div>
          </div>
        </div>
      </section>
      
      {/* Qualification Requirements */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              Do I Qualify?
            </h2>
            <p style={{ fontSize: 18, color: colors.textLight }}>
              Here's what our lending partner looks for
            </p>
          </div>
          
          <div className="grid-3-col" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {[
              {
                title: 'Credit Score',
                requirement: '620 or higher',
                details: 'Don\'t know your score? We\'ll help you check it for free.',
                icon: '📊'
              },
              {
                title: 'Income',
                requirement: '30% rule',
                details: '30% of your take-home pay should cover the monthly payment.',
                icon: '💵'
              },
              {
                title: 'Intent',
                requirement: 'Owner-Occupant',
                details: 'You must plan to live in the home. No investors.',
                icon: '🏠'
              }
            ].map(item => (
              <div key={item.title} className="hover-lift" style={{
                background: 'white',
                borderRadius: 20,
                padding: 32,
                textAlign: 'center',
                boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
              }}>
                <div style={{ fontSize: 40, marginBottom: 16 }}>{item.icon}</div>
                <h3 style={{ fontSize: 20, fontWeight: 600, color: colors.primary, marginBottom: 8 }}>{item.title}</h3>
                <div style={{ fontSize: 24, fontWeight: 700, color: colors.accent, marginBottom: 12 }}>{item.requirement}</div>
                <p style={{ fontSize: 14, color: colors.textLight, lineHeight: 1.5 }}>{item.details}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Not Qualified Yet? */}
      <section style={{ padding: '80px 24px', background: colors.backgroundAlt }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              Not Qualified Yet? We Can Help.
            </h2>
            <p style={{ fontSize: 18, color: colors.textLight, maxWidth: 600, margin: '0 auto' }}>
              If you don't qualify today, we won't just turn you away. We'll help you get there.
            </p>
          </div>
          
          <div className="grid-2-col" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24 }}>
            <div className="hover-lift" style={{
              background: 'white',
              borderRadius: 20,
              padding: 32,
              boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
            }}>
              <div style={{ fontSize: 32, marginBottom: 16 }}>📈</div>
              <h3 style={{ fontSize: 20, fontWeight: 600, color: colors.primary, marginBottom: 12 }}>Credit Below 620?</h3>
              <p style={{ fontSize: 15, color: colors.textLight, lineHeight: 1.7, marginBottom: 16 }}>
                We'll connect you with credit counseling resources that can help you improve your score. Many people raise their score 50+ points in just 6-12 months.
              </p>
              <ul style={{ listStyle: 'none', padding: 0 }}>
                {['Free credit counseling referrals', 'Monthly check-ins from our team', 'Priority consideration when qualified'].map(item => (
                  <li key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, fontSize: 14, color: colors.textLight }}>
                    <span style={{ color: colors.accent }}>✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="hover-lift" style={{
              background: 'white',
              borderRadius: 20,
              padding: 32,
              boxShadow: '0 4px 30px rgba(0,0,0,0.06)'
            }}>
              <div style={{ fontSize: 32, marginBottom: 16 }}>💼</div>
              <h3 style={{ fontSize: 20, fontWeight: 600, color: colors.primary, marginBottom: 12 }}>Income Too Low?</h3>
              <p style={{ fontSize: 15, color: colors.textLight, lineHeight: 1.7, marginBottom: 16 }}>
                We partner with career development organizations to help you increase your earning potential. A better job means a better home is possible.
              </p>
              <ul style={{ listStyle: 'none', padding: 0 }}>
                {['Career counseling connections', 'Skills training resources', 'Job placement assistance'].map(item => (
                  <li key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, fontSize: 14, color: colors.textLight }}>
                    <span style={{ color: colors.accent }}>✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Compare Section */}
      <section style={{ padding: '80px 24px', background: colors.background }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 className="headline-font" style={{ fontSize: 'clamp(28px, 4vw, 40px)', color: colors.text, marginBottom: 16 }}>
              RediHome vs. Traditional Home Buying
            </h2>
          </div>
          
          <div style={{
            background: 'white',
            borderRadius: 20,
            overflow: 'hidden',
            boxShadow: '0 4px 30px rgba(0,0,0,0.08)'
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', borderBottom: '1px solid #eee' }}>
              <div style={{ padding: 20, fontWeight: 600, color: colors.textLight }}></div>
              <div style={{ padding: 20, fontWeight: 600, color: colors.textLight, textAlign: 'center', background: colors.backgroundAlt }}>Traditional</div>
              <div style={{ padding: 20, fontWeight: 600, color: 'white', textAlign: 'center', background: colors.primary }}>RediHome</div>
            </div>
            
            {[
              { label: 'Down Payment', trad: '3-20%', redi: '0%' },
              { label: 'PMI Required', trad: 'Yes (if <20% down)', redi: 'No' },
              { label: 'Minimum Credit', trad: '620-680+', redi: '620' },
              { label: 'Time to Move In', trad: '3-12 months', redi: '8 weeks' },
              { label: 'Hidden Fees', trad: 'Common', redi: 'Transparent' },
              { label: 'Realtor Commissions', trad: '5-6%', redi: 'Flat fee' }
            ].map((row, idx) => (
              <div key={row.label} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', borderBottom: idx < 5 ? '1px solid #eee' : 'none' }}>
                <div style={{ padding: 16, fontSize: 14, color: colors.text, fontWeight: 500 }}>{row.label}</div>
                <div style={{ padding: 16, fontSize: 14, color: colors.textLight, textAlign: 'center', background: colors.backgroundAlt }}>{row.trad}</div>
                <div style={{ padding: 16, fontSize: 14, color: colors.accent, textAlign: 'center', fontWeight: 600 }}>{row.redi}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <CTASection />
      <Footer />
    </div>
  );
}
